import { getAllowedDomains } from "../common/whitelist.js";

Office.onReady(init);

function getDomain(email) {
  return email.split("@")[1]?.toLowerCase();
}

function getTrustedRecipients() {
  const trusted = Office.context.roamingSettings.get("trustedRecipients");
  return trusted ? JSON.parse(trusted) : [];
}

function saveTrustedRecipients(list) {
  Office.context.roamingSettings.set("trustedRecipients", JSON.stringify(list));
  Office.context.roamingSettings.saveAsync();
}

function getAllRecipients() {
  const item = Office.context.mailbox.item;

  return new Promise((resolve) => {
    item.to.getAsync(toRes => {
      item.cc.getAsync(ccRes => {
        item.bcc.getAsync(bccRes => {
          resolve([
            ...(toRes.value || []),
            ...(ccRes.value || []),
            ...(bccRes.value || [])
          ].map(r => r.emailAddress.toLowerCase()));
        });
      });
    });
  });
}

let externalCache = [];

async function init() {
  const allowedDomains = await getAllowedDomains();
  const recipients = await getAllRecipients();
  const trusted = getTrustedRecipients();

  const allowedList = document.getElementById("allowedList");
  allowedDomains.forEach(d => {
    const li = document.createElement("li");
    li.innerText = d;
    allowedList.appendChild(li);
  });

  externalCache = recipients.filter(e => {
    const domain = getDomain(e);
    return !allowedDomains.includes(domain) && !trusted.includes(e);
  });

  renderExternal(externalCache);

  document.getElementById("searchBox").addEventListener("input", (e) => {
    const val = e.target.value.toLowerCase();
    renderExternal(externalCache.filter(x => x.includes(val)));
  });

  document.getElementById("saveBtn").onclick = () => {
    const selected = [...document.querySelectorAll("input:checked")]
      .map(cb => cb.value);

    const updated = [...new Set([...trusted, ...selected])];
    saveTrustedRecipients(updated);
    location.reload();
  };
}

function renderExternal(list) {
  const container = document.getElementById("externalList");
  container.innerHTML = "";

  list.forEach(email => {
    const div = document.createElement("div");
    div.innerHTML = `<input type="checkbox" value="${email}" /> ${email}`;
    container.appendChild(div);
  });
}