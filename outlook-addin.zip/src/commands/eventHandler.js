import { getAllowedDomains } from "../common/whitelist.js";

function getDomain(email) {
  return email.split("@")[1]?.toLowerCase();
}

function extractDomains(emails) {
  const domains = emails.map(e => getDomain(e)).filter(Boolean);
  return [...new Set(domains)];
}

function formatDomains(domains, max = 5) {
  if (domains.length <= max) return domains.join(", ");
  return domains.slice(0, max).join(", ") + ` +${domains.length - max} więcej`;
}

function buildMessage(emails) {
  const domains = extractDomains(emails);
  return `Wysyłasz do zewnętrznych domen: ${formatDomains(domains)}. Kontynuować?`;
}

function getTrustedRecipients() {
  const trusted = Office.context.roamingSettings.get("trustedRecipients");
  return trusted ? JSON.parse(trusted) : [];
}

function getAllRecipients(item) {
  return new Promise((resolve) => {
    item.to.getAsync(toRes => {
      item.cc.getAsync(ccRes => {
        item.bcc.getAsync(bccRes => {
          const all = [...(toRes.value||[]), ...(ccRes.value||[]), ...(bccRes.value||[])];
          resolve(all.map(r => r.emailAddress.toLowerCase()));
        });
      });
    });
  });
}

export async function onMessageSendHandler(event) {
  const item = Office.context.mailbox.item;

  const recipients = await getAllRecipients(item);
  const allowed = await getAllowedDomains();
  const trusted = getTrustedRecipients();

  const external = recipients.filter(e => {
    const domain = getDomain(e);
    return !allowed.includes(domain) && !trusted.includes(e);
  });

  if (external.length > 0) {
    event.completed({
      allowEvent: false,
      errorMessage: buildMessage(external)
    });
  } else {
    event.completed({ allowEvent: true });
  }
}