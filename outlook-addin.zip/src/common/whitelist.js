const CACHE_KEY = "allowedDomainsCache";
const CACHE_TTL = 6 * 60 * 60 * 1000;

export async function getAllowedDomains() {
  const cached = localStorage.getItem(CACHE_KEY);

  if (cached) {
    const parsed = JSON.parse(cached);
    if (Date.now() - parsed.timestamp < CACHE_TTL) {
      return parsed.data.allowedDomains;
    }
  }

  try {
    const res = await fetch("/data/allowedDomains.json");
    const data = await res.json();

    localStorage.setItem(CACHE_KEY, JSON.stringify({
      timestamp: Date.now(),
      data
    }));

    return data.allowedDomains;

  } catch (e) {
    if (cached) {
      return JSON.parse(cached).data.allowedDomains;
    }
    return [];
  }
}