import { findExternalRecipients } from "../services/domainChecker.js";
import { showWarning, clearWarning } from "../ui/notification.js";

const ALLOWED_DOMAIN = "test.dd";

export function onRecipientsChanged(event) {
    const item = Office.context.mailbox.item;

    Promise.all([
        getRecipients(item.to),
        getRecipients(item.cc),
        getRecipients(item.bcc)
    ])
    .then(([to, cc, bcc]) => {
        const all = [...to, ...cc, ...bcc];

        const external = findExternalRecipients(all, ALLOWED_DOMAIN);

        if (external.length > 0) {
            showWarning(external);
        } else {
            clearWarning();
        }
    })
    .catch(console.error)
    .finally(() => event.completed());
}

function getRecipients(field) {
    return new Promise((resolve) => {
        field.getAsync(result => {
            resolve(result.value || []);
        });
    });
}
