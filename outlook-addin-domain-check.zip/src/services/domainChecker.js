export function isExternal(email, allowedDomain) {
    if (!email) return false;
    return !email.toLowerCase().endsWith("@" + allowedDomain);
}

export function findExternalRecipients(recipients, allowedDomain) {
    return recipients.filter(r =>
        isExternal(r.emailAddress, allowedDomain)
    );
}
