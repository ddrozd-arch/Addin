const ID = "externalRecipientsWarning";

export function showWarning(externals) {
    const emails = externals.map(e => e.emailAddress).join(", ");

    Office.context.mailbox.item.notificationMessages.replaceAsync(ID, {
        type: Office.MailboxEnums.ItemNotificationMessageType.InformationalMessage,
        message: `Uwaga! Adresaci spoza domeny: ${emails}`,
        icon: "icon16",
        persistent: true
    });
}

export function clearWarning() {
    Office.context.mailbox.item.notificationMessages.removeAsync(ID);
}
