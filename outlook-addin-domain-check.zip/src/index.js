import { onRecipientsChanged } from "./events/recipientsChanged.js";

Office.onReady(() => {
    window.onRecipientsChanged = onRecipientsChanged;
});
